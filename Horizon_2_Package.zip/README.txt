HORIZON 2 PACKAGE — CONTENTS & USE
===================================
01_Horizon_2_Roadmap_CLIENT_DELIVERABLE.pdf
    The client-facing document (visuals embedded). This is the one you may
    deliver alongside the pitch documents — written in the client voice.
02_Horizon_2_Internal_Proposal_INTERVIEW_PREP.pdf
    Your prep version: interview logic, 60-second script, deployment rules.
    DO NOT send to the panel — this is what you know, not what you send.
slides/
    The three boardroom visuals at 1920x1080 for the deck or video:
    H2_1 Patient Implant Passport (MDR Art. 18)
    H2_2 EUDAMED Autopilot (legacy deadline 27 Nov 2026)
    H2_3 Compliance Copilot (Odoo 19 native AI, governed)
DEPLOYMENT RULE: Horizon 2 is ONE slide after The Ask plus this leave-behind
PDF — a horizon, not a second proposal.
