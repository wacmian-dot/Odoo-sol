PACKAGE v3 — WHAT'S NEW OVER v2
================================
08_Live_Demo_Evidence/   The verified build log of the live Odoo instance (six fire-tested
                         compliance controls) + the independent audit that hardened it.
                         THE DEMO WALKTHROUGH AND 12-SHOT SCREENSHOT LIST LIVE HERE.
09_Video_Production/     Blueprint, timed voice-over script and captions for the 5-6 min
                         demo video. Video file itself intentionally NOT in this package —
                         Waqas screen-records the live instance himself using the blueprint.
10_Strategy_and_Horizon_2/  Principal Consultant briefing (pitch narrative, cheat sheet,
                         gap fixer) + HORIZON 2: the standout next-sale proposal
                         (EUDAMED Autopilot - deadline 27 Nov 2026, Patient Implant
                         Passport - MDR Art. 18, Compliance Copilot - Odoo 19 native AI)
                         with three boardroom-ready slide visuals in /slides.
SUBMISSION RULE (unchanged): the client-facing set is the memo + the deck. Everything
else is preparation. Horizon 2 = ONE slide after The Ask + one line in the memo.
