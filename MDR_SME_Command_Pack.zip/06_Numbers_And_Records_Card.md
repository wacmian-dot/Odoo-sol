# Numbers & Records Card — Every Figure On One Page
*If a number leaves your mouth in the room, it comes from this card.*

## Money
| € | What |
|---|---|
| **4,850** | INV/2026/00001 — posted invoice, Klinikum München Ost (surgery SN-HC-0001, Dr. Weber); 100% analytic distribution on 3 plans |
| **1,200** | Implant standard cost (HipCore Ti-64) — the on-book value of SN-HC-0002 at the consignment location |
| **120** | Raw material (Ti-6Al-4V rod) standard cost |
| **3,000** | Instrument tray standard cost |
| *Fee* | **Deliberate placeholder** — "a fee printed in a pre-read before discovery would be a guess dressed as a promise" |

## Clocks & counts
| Value | What |
|---|---|
| **90 days** | Quality hold, auto-stamped at receipt (LOT-2607-B: received Jul 2026 → hold until **01/10/2026**) |
| **730 days** | Sterility clock on the implant (expiration dates on) → GS1 (17) 280702 = 02 Jul 2028 |
| **50** | Sterilization cycle limit (TRAY-A-001 at 1/50; TRAY-B-001 at 50/50 → dispatch refused) |
| **10 / 50** | Reordering rule min/max on raw material, scoped to WH/Stock only |
| **16** | UAT scenarios — **15 PASS, 1 SIMULATED** (T-14, Field Service off trial tier) |
| **4** | Enforced automation rules (credential gate, auto-hold, quarantine gate, cycle control) |
| **19 (+17b)** | Regression suite TC-01…TC-19 incl. TC-17b — runs on every release candidate |
| **22** | RTM rows R-01…R-22 |
| **5** | Named extensions: UDI reporting depth · recall/consignment depth · multi-payer & rebate · instrument reprocessing · QA dual-release gate |
| **15 (+deck)** | Client documents in the package (00–13, 15) + pitch deck (14) |
| **3** | Analytic plans: Cost Center · Payer Type · Product Line (native since Odoo 16) |
| **3 weeks** | Discovery Sprint, fixed fee |
| **~1 day/week** | Client effort: two process owners per department during their sprint |
| **90 days** | Default parallel-run window (shorter of 90d or oldest open record's closure) — discovery-confirmed position |

## Records (the cast)
| ID | Role |
|---|---|
| LOT-2607-A | Raw lot, released, consumed into SN-HC-0003 (MO WH/MO/00004) |
| LOT-2607-B | Raw lot, 10 units, QC passed, HELD in quarantine until 01/10/2026 — refusal demo |
| SN-HC-0001 | Consumed at surgery → INV/2026/00001 |
| SN-HC-0002 | Consigned, Klinikum München, €1,200 on-book |
| SN-HC-0003 | Returned → Quarantine/Returns; UDI DI 04012345678901; composite **(10)LOT-2607-A(21)SN-HC-0003(17)280702** |
| TRAY-A-001 / TRAY-B-001 | Cycle 1/50 in loop / 50/50 refused-retire |
| S00001 / S00002 / S00004 | Feldmann BLOCKED / Weber confirmed / Okafor confirmed+review |
| WH/IN/00002 | OrthoAlloy receipt, 10 units → quarantine |
| Dr. A. Weber | Validated, DE-ORT-5512, expiry 31/12/2027 |
| Dr. M. Feldmann | Expired 30/04/2026 — the block |
| Dr. S. Okafor | Locum, Pending Verification — the review route |

## Regulatory dates (must be word-perfect)
| Date | Fact |
|---|---|
| **28 May 2026** | EUDAMED first modules (incl. UDI/device registration) mandatory |
| **27 Nov 2026** | Legacy devices on the market must be registered — Horizon 2 Move 1's statutory anchor |
| **10–15 years** | MDR retention for implantables (post-manufacture) |
| Odoo **16** | Multiple analytic plans became native |
| Odoo **19** | Native AI agents (Topics/Sources, Restrict-to-Sources; no action topics = read-only by platform) |
| saas~**19.3** | Demo instance version line |

## GAMP / test chips
- Category **4** = native core (configured product) · Category **5** = the five named extensions (validated on own track).
- RTM evidence chips: **F** = Fire-tested (refusal recorded) · **L** = Verified live · **D** = Design-ready · **S** = Discovery-scoped.
- The four fire-tested controls map to UAT: T-03 (credential), T-05 (locum route), T-08 (hold), T-13 (cycle limit).
