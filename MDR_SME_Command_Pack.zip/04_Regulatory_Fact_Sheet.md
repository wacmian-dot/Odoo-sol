# Regulatory Fact Sheet — Every Citation, What It Actually Says
*Quote-ready. If you cite it in the room, you must survive "what does that article actually require?"*

## EU MDR (Regulation 2017/745)
| Provision | What it requires | Where the package answers it |
|---|---|---|
| **Article 27** — UDI system | Devices carry a Unique Device Identification (UDI = DI + PI); manufacturers assign, register, and keep UDI records; for **Class III implantables**, economic operators must store UDIs of devices they supplied/received | The UDI data model on `stock.lot` (DI + GS1-structured PI), scan capture with provenance, traceability report = "Article 27 evidence in one screen" (UAT T-16) |
| **Article 18** — implant card | Manufacturers of implantable devices supply an implant card (device name, serial, UDI, manufacturer) + keep lay-language, patient-accessible info updated on their website, in the patient's language | Horizon 2 Move 2 — Patient Implant Passport: card auto-generated from the serial's UDI record at Surgery Complete; portal page + QR. Layout per **MDCG 2019-8** guidance |
| **Articles 83–86** — post-market surveillance | Manufacturers run a proportionate PMS system feeding a PMS report/PSUR; it grows with device classes | Horizon 2 Move 3 / AI Addendum: PMS trend watch across returns, complaints, reprocessing — honest adoption after 6–12 months of thread data |
| **Article 10(8)** & Annex — record retention | Technical documentation kept ≥10 years after last device placed (≥**15 years for implantables**) | The "two retention rules on one record" GDPR-vs-MDR design position; legacy read-only archive at cutover |

## EUDAMED (the dates that must be perfect)
- Phased-mandate legal vehicle: **Regulation (EU) 2024/1860** (amending MDR/IVDR) — gradual mandatory rollout of finished modules.
- **28 May 2026**: first module group — including **UDI/device registration** — mandatory. New devices: register before placing on the EU market.
- **27 November 2026**: deadline to register **legacy/already-marketed devices**. → This is the statutory anchor of Horizon 2 Move 1 (EUDAMED Autopilot + bulk legacy registration as managed service).
- Machine-to-machine (M2M) submission: Commission publishes the spec; Autopilot sized against the current M2M spec at build time. Today most of the industry meets this with spreadsheets and manual portal entry.

## GAMP 5 (ISPE guidance, 2nd edition)
- **Category 3**: non-configured product. **Category 4**: configured product — validated via Configuration Specification + risk-based testing. **Category 5**: custom application — full lifecycle rigor (design spec, code-level review where applicable, dedicated regression).
- Package position: **mixed classification** — native core Cat 4; the five named extensions Cat 5 *by function, not by implementation technology* (they're Studio-based but exceed native behavior). Risk-proportionate validation is the GAMP 5 second-edition ethos: critical thinking over blanket rigor.
- Lifecycle in the VMP: URS → Functional Risk Assessment → Configuration Spec → Traceability Matrix → IQ → OQ → PQ → Validation Summary Report; periodic review per release cycle; regression suite TC-01…TC-19 gates every promotion.

## EU GMP Annex 11 (EudraLex Volume 4) — "Computerised Systems"
- The EU GxP benchmark for computerized systems: risk management, supplier assessment, **audit trails** (who/what/when, review of changes), **access controls**, periodic evaluation, electronic signature expectations, data integrity.
- How you cite it: "Annex 11 is EU GMP — EudraLex Volume 4 — applied here, alongside 21 CFR Part 11 and ISO 13485, as the accepted GxP benchmark for computerized systems in device manufacturing." (Device-land legally runs on MDR + ISO 13485; Annex 11 is applied as benchmark practice — that phrasing is the precise, defensible one.)

## 21 CFR Part 11 (FDA — electronic records & signatures)
- **§11.10** controls for closed systems: validation, audit trails, authority checks, operational checks, record protection/retention.
- **§11.50** signature manifestations: signed records show printed name, date/time, meaning of signature.
- Package use: the two-step QA release gate satisfies the **dual-control intent** of §11.10/11.50 — two authenticated, separately-permissioned, independently timestamped actions — while stating plainly Odoo has no native dual-auth e-signature. Relevant to MDR Devices for any US market exposure (21 CFR 820 QSR context) and as lingua franca with auditors.

## ISO 13485 (QMS for medical devices)
- The QMS standard notified bodies certify against; requires documented control of production, identification & **traceability** (§7.5.8/7.5.9 — especially implantables), control of monitoring/measurement, CAPA.
- Package mapping: Odoo Quality module workflows + the thread give the traceability and production-control evidence; CAPA/complaints workflows consolidate into Odoo Quality (LIMS position: integrate, not replace).

## GDPR
- **Article 9**: health data = special category — processing prohibited unless a specific lawful basis applies. Patient-linked fields in CRM are Art. 9 territory.
- **DPIA** (Art. 35): likely mandatory before go-live given volume + sensitivity. Named workstream, owned by MDR legal/DPO.
- Controller/processor (Art. 28): if hospitals enter patient data into MDR's CRM → relationship needs its own agreement; confirm who is controller.
- The named tension: MDR retention (10–15y implantables) vs. GDPR minimization → two retention rules layered on one record (device history persists; patient-identifying fields may not).

## One-liners you can deploy verbatim
- "A control that has never refused anything is just a setting."
- "Compliance by structure, not by memory."
- "The gates are deterministic; AI accelerates the people above them."
- "Article 27 evidence in one screen."
- "We don't sell zero custom code. We sell *named* custom code."
- "The deadline is met once; the synchronization is met forever." (EUDAMED)
- "A return is a continuation of history, not a new record."
