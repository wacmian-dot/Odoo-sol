# Technical Deep-Dive — The Odoo Machinery Behind Every Claim
*Everything three levels down, so "how exactly does that work?" never reaches bottom.*

## 1 · The instance
- Odoo Enterprise SaaS (version line saas~19.3), trial tenant renamed **MDR Devices Medizintechnik GmbH** — every screen carries client identity.
- Apps installed: Inventory, Purchase, Manufacturing, Quality, Sales, CRM, Accounting, Barcode (+ Studio for fields/views). Field Service NOT available on the trial tier (why T-14 is SIMULATED).
- Build method: external API (XML-RPC — `/xmlrpc/2/common` for auth, `/xmlrpc/2/object` `execute_kw` for CRUD) plus Studio. No custom Python modules deployed. If asked "could you script that migration?" — yes, and this build is the proof.

## 2 · Location architecture (the compliance geography)
```
WH/Stock                              internal — the ONLY replenishment-counted location
WH/Quarantine                         internal — all inbound lands here (receipt operation default dest)
WH/Quarantine/Disposition             internal — failed-check routing; exit only Scrap / RTV / Extended Hold
WH/Quarantine/Returns                 internal — reverse flow (Stage 4B) awaiting disposition
WH/Consignment/Klinikum München       internal — hospital stock, on MDR's books until consumption
WH/Sterilization                      internal — instrument loop; autoclave QCP gates the exit
```
Key mechanism: the **Receipt operation type's default destination = WH/Quarantine** — quarantine is unavoidable by configuration, not by SOP. Reordering rule on raw material (min 10 / max 50) is scoped to WH/Stock only, so quarantined stock never satisfies replenishment — that's the literal answer to the brief's auto-replenish requirement.

## 3 · Products & tracking
| Product | Tracking | Config |
|---|---|---|
| HipCore Ti-64 Femoral Stem (IMP-HC-001) | Unique serial | Expiration dates on (730-day sterility clock), Manufacture route, BoM: 1 × Ti rod, std cost €1,200 |
| Ti-6Al-4V Rod Stock (raw) | Lot | Buy route, vendor OrthoAlloy GmbH, reordering 10/50 on WH/Stock, std cost €120 |
| Instrument Tray (Loaner) | Unique serial | Reusable asset on the reprocessing loop, std cost €3,000 |

Costing: Goods category → **Standard Price**; valuation **periodic** on the trial (perpetual + stock-account wiring = Sprint 2 with finance, Risk Register RK-07). War story if asked: FIFO initially overrode the intended costs silently — caught because ledger numbers didn't match the documents; switched category costing and re-verified every figure. (Also in the AI correction log.)

## 4 · Custom field inventory (exact API names)
**On `res.partner`:** `x_hcp_certification_number` (Char) · `x_hcp_certification_expiry` (Date) · `x_validation_state` (Selection: Draft / Validated / Expired / Suspended / Pending Verification).
**On `stock.lot`:** `x_udi_di` (Char, Device Identifier) · `x_udi_pi` (composite) + `_batch` / `_serial` / `_expiry` splits (GS1 AI 10/21/17) · `x_udi_source` (Selection: Scanned GS1 / Manual — provenance itself auditable) · `x_hold_release_date` (Date, stamped receipt+90d) · `x_sterilization_cycle_count` / `_limit` (Integer) · `x_return_disposition` (Selection: Re-Quarantine / Scrap / Return-to-Vendor / Under Investigation) · `x_return_reason` (Char).
All surfaced in a dedicated **"MDR Compliance — UDI & Quality"** section on the record forms (originally configured but invisible — caught in review, now screenshot evidence in UAT T-10).

## 5 · The four automation rules (`base.automation`)
| Rule | Trigger | Logic | Proof |
|---|---|---|---|
| MDR Credential Gate | sale.order confirmation | state ∈ {expired,suspended} OR expiry < today → `raise UserError` (order stays Draft); state pending/empty → confirm + `activity_schedule` mandatory review + chatter post | T-03 block, T-04 pass, T-05 route |
| Auto Quality Hold | stock.lot create (raw) | writes `x_hold_release_date` = receipt + 90 days | T-06/T-08 |
| GxP Quarantine Hold Gate | transfer validation | refuses moves out of WH/Quarantine before hold date AND without QC pass (both conditions); Disposition route exempt | T-08 |
| Sterilization Cycle Control | transfer validation | +1 on entry to WH/Sterilization; blocks dispatch to consignment when count ≥ limit | T-13 |

Gate logic pattern (credential gate, representative — reproduced in FS-05 §8.1): iterate records → read partner state/expiry → `raise UserError("Blocked — HCP certification expired or invalid for %s...")` → else if pending → `activity_schedule("mail.mail_activity_data_todo", summary="HCP credential verification required")` + `message_post`.

## 6 · Quality Control Points (`quality.point` → `quality.check`)
1. **Inbound Implant Material Inspection** — on Receipts, raw material: visual, storage-condition review, CoA verification. Receipt cannot validate with an open check.
2. **Autoclave Cycle Verification** — on internal transfers of trays: records cycle reference + parameters (temperature, duration, pressure); notes require second-person countersign before redeploy (aligns to two-step release design).
Quality checks link to the lot; pass/fail recorded with user + timestamp in chatter.

## 7 · Traceability mechanics
Serial created at MO completion; backflush consumption links raw lot → finished serial (WH/MO/00004: consumed LOT-2607-A ×1 → produced SN-HC-0003). The Traceability report from any lot/serial renders the full chain: vendor receipt → quarantine → QC/hold → manufacture → consignment → consumption/return, with dates, quantities, references (T-16 — "MDR Article 27 evidence in one screen"). Returns write disposition onto the SAME lot record — a return is a continuation of history, not a new record.

## 8 · Financial spine
Three analytic plans (native Odoo 16+): **Cost Center, Payer Type, Product Line**. INV/2026/00001 (€4,850, Klinikum München Ost, posted) carries 100% distribution across all three on the implant line. Native boundary stated precisely: one SO invoices one partner → payer-split (insurer + co-pay; multi-tier) is extension scope; the analytic spine those splits reconcile through is native and demonstrated.

## 9 · Audit trail mechanics
`mail.thread` chatter + `tracking=True` on critical fields = timestamped, user-attributed change log, system-written (not UI-editable). Critical models `stock.lot`, `quality.check`, `account.move` → archive-only policy (no hard-delete path in the validated boundary). Layered honesty for auditors: application-layer controls + admin-access governance in IQ/OQ scope + Odoo.sh promotion as the only sanctioned change path.

## 10 · Demo dataset state (know cold — this IS the system)
| Record | State |
|---|---|
| LOT-2607-A (raw) | Released; consumed ×1 into SN-HC-0003 via WH/MO/00004 |
| LOT-2607-B (raw, 10 units, WH/IN/00002 from OrthoAlloy) | QC PASSED but **held in WH/Quarantine until 2026-10-01** — the refusal demo |
| SN-HC-0001 | Consumed (surgery, Dr. Weber) → invoiced INV/2026/00001 €4,850 |
| SN-HC-0002 | Consigned at WH/Consignment/Klinikum München, €1,200 on-book |
| SN-HC-0003 | Returned → WH/Quarantine/Returns, disposition logged; full UDI: DI 04012345678901, composite (10)LOT-2607-A(21)SN-HC-0003(17)280702 |
| TRAY-A-001 | Cycle 1/50, in sterilization loop |
| TRAY-B-001 | Cycle 50/50 — dispatch REFUSED ("route to retirement") |
| Dr. A. Weber | Validated, cert DE-ORT-5512, expiry 31/12/2027 → S00002 confirmed |
| Dr. M. Feldmann | Expired 30/04/2026 → S00001 BLOCKED in Draft |
| Dr. S. Okafor | Locum, Pending Verification → S00004 confirmed + review activity |

## 11 · Known boundaries list (say them before they're asked)
1. No native dual-auth e-signature → designed two-step release gate (Cat 5). 2. Payer-split invoicing not native → extension. 3. EUDAMED M2M → Horizon 2. 4. Field Service off-tier → T-14 SIMULATED. 5. Perpetual valuation → Sprint 2 with finance. 6. Demo not permission-hardened (role matrix is delivery scope — IQ verifies it). 7. Hospital IT integration (HL7/FHIR/DICOM) deliberately out of Phase 1 — own workstream, like the LIMS.

## 12 · SAP → Odoo translation table (your bridge vocabulary)
| SAP concept | Odoo equivalent |
|---|---|
| Batch / serial master (MCH1, EQUI/SERNR) | `stock.lot` (one model for lots AND serials) |
| Storage location / MM-IM | `stock.location` tree + location usage types |
| QM inspection lot + usage decision | `quality.point` → `quality.check` + disposition routing |
| Batch where-used (MB56) | Traceability report from any lot/serial |
| CO cost center / PA dimensions | Analytic plans + distributions |
| Output/condition-based blocks (status mgmt) | `base.automation` rules raising UserError |
| Transport requests (STMS) | Odoo.sh staging branch → controlled promotion |
| ABAP enhancement | Studio field/automation (data-resident, upgrade-carried) |
