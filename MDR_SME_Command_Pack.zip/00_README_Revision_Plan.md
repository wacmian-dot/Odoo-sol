# SME Command Pack — How To Use This
*Personal preparation pack. NOTHING in this zip goes to the client or the panel except the one PDF marked HANDOUT.*

## What's in the pack
| # | File | Purpose | Study tier |
|---|---|---|---|
| 00 | This README | Revision plan | — |
| 01 | Opening_Elevator_Pitch.md | The cold-memorized 2 minutes | **COLD** |
| 02 | Master_QA_Drill.md | ~45 hardest questions with model answers (6 domains) | **WARM** |
| 03 | Technical_Deep_Dive_Odoo.md | The machinery behind every claim, 3 levels down + SAP→Odoo translation table | **WARM** |
| 04 | Regulatory_Fact_Sheet.md | Every citation and what it actually says + deployable one-liners | **WARM** |
| 05 | Demo_Runbook_Presentation.md | The show path, 9 stops, recovery moves, don'ts | **COLD (the path), WARM (recovery)** |
| 06 | Numbers_And_Records_Card.md | Every figure on one page | **COLD** |
| 07 | MUCH_Alignment_Dossier.md | Their vocabulary, the Managing Partner's talk, the one-liners | **WARM** |
| 08 | AI_Journey_Presentation_Notes.md | When/how to play the working-method note | **WARM** |
| 09 | AI_Working_Method_Note.pdf | **HANDOUT** — the only outward-facing file in this pack | — |
| 10 | Interview_Rebuttal_Playbook.pdf | 20 objection-defense scenarios (earlier prep round — still valid) | REFERENCE |
| 11 | Rehearsal_Cue_Card.pdf | Pocket drill sheet from earlier round | REFERENCE |
| 12 | Live_Presentation_Script.pdf | Verbatim narration (earlier round — the beats still hold) | REFERENCE |
| 13 | Demo_Build_Runbook.md | How the system was BUILT (if asked to reproduce anything) | REFERENCE |
| 14 | Peer_Review_Final_Report.md | Proof of the QA process — feeds the AI-journey story | REFERENCE |

**Tiers:** COLD = recite without notes. WARM = know the substance, own words fine. REFERENCE = know it exists and where.

## The 3-day plan (adjust to what's left before Monday)
**Day 1 — Own the system.** Read 03 (Deep-Dive) twice. Log into the instance and physically click every stop in 05 while reading it. Then read 06 (Numbers) and test yourself: cover the right column, recite. Evening: 01 (Elevator) — three clean out-loud runs.
**Day 2 — Withstand the fire.** 02 (Q&A drill), out loud, answer-before-reading, sections F → A → B. Mark every fumble. Then 04 (Regulatory) — the dates and the "what does that article say" test. Re-drill only the fumbles. Evening: 07 (much. dossier) + 08 (AI playbook) — once each, they're about *placement*, not memorization.
**Day 3 — Full dress.** Morning: complete run — elevator pitch cold, then the 9-stop demo live against the real instance with the script beats, then a self-administered rapid-fire from 02 section F. Afternoon: fumble list only. Evening: STOP. Read 06 once before bed, nothing else.

**Morning-of checklist:** instance alive → record states verified (S00001 Draft, LOT-2607-B held, TRAY-B-001 undipatched) → UAT PDF open in a tab → printed working-method note in the bag → elevator pitch once in the car, not in the lobby.

## The posture (one paragraph to remember)
You are not defending documents; you are showing a system you built and tested. Every hard question has one of three honest shapes: **demonstrated** (show it or cite the UAT scenario), **design-ready** (name the mechanism and where it's specified), or **discovery-scoped** (name it as deliberately unresolved and who resolves it). If a question genuinely lands outside all three: "I don't know — here's how I'd find out inside a day." Said once, confidently, that answer *raises* your credibility. Said twice, it's fine. Faking it once ends the interview.
