# Master Q&A Drill — Withstand Any Question
*Model answers in your voice. Drill rule: read the question, answer out loud BEFORE reading the model answer. Anything you fumble twice goes on the cue card.*

---

## A · Odoo platform & technical mechanics

**A1. "Why Odoo for a regulated MedTech manufacturer and not SAP — you're a SAP architect, surely SAP is safer?"**
Because the requirement set is mid-market MedTech, not global enterprise. SAP would cover it — at 3–5× the license and implementation cost, on a longer timeline, with the same custom work still needed for UDI depth and consignment reporting. Odoo covers the majority of the process footprint natively on one data model, and the gaps are named, small, and validatable. I *know* what the SAP path costs — that's precisely why I can say with confidence it's the wrong tool for this client. My SAP background isn't a bias toward SAP; it's a calibrated benchmark against it.

**A2. "How exactly does the credential gate work — walk me through the mechanism."**
Three custom fields on `res.partner` — certification number, certification expiry (Date), and a validation-state selection (Draft / Validated / Expired / Suspended / Pending Verification). An automation rule fires on sale-order confirmation: if the partner's state is Expired/Suspended, or the expiry date is past, it raises a blocking validation error and the order stays in Draft. If the state is Pending Verification (the locum case), it lets the order confirm but creates a mandatory review activity and logs the routing in the chatter. Hard block for known-bad, review queue for unknown — that's deliberate: you don't block legitimate surgery for paperwork latency.

**A3. "Automation rules — what are they technically, and where do they live?"**
`base.automation` records — trigger definitions (on create/update, on state transition) bound to a model, executing server actions. In the demo they're visible under technical settings; four carry the compliance load: credential gate (sale.order confirm), auto hold-stamp (stock.lot create → hold date = receipt +90 days), quarantine release gate (transfer validation out of WH/Quarantine), sterilization cycle control (transfer validation — increments on entry to the sterilization location, blocks dispatch at count ≥ limit). In production these move into the named extension layer under GAMP Category 5 with change control and the TC-01…TC-19 regression suite.

**A4. "Why is the hospital consignment location an INTERNAL location? Isn't that a hack?"**
It's the standard Odoo pattern for consignment you still own. Location usage `internal` means stock there counts in your valuation — which is exactly the accounting truth of consignment: physical custody transfers to the hospital, legal ownership and balance-sheet value stay with MDR until consumption. The demo proves it: SN-HC-0002 sits at WH/Consignment/Klinikum München at €1,200 on MDR's books. The commercial consignment agreement governs the legal side; the location type makes the ledger tell the truth.

**A5. "Why standard costing in the demo? Real manufacturers use FIFO or average."**
Deliberate demo choice, stated in the Functional Spec. On the trial tier I wanted deterministic, explainable valuation numbers so every euro in the documents reconciles to the ledger — standard cost gives that. Costing method selection (standard vs. FIFO vs. AVCO) and perpetual valuation with stock-account wiring are explicit Sprint 2 configuration decisions with finance sign-off — it's in the Risk Register as RK-07. I'd never present a costing method as decided before discovery has seen the client's actual cost accounting policy.

**A6. "What are the three analytic plans and since when does Odoo support that?"**
Cost Center, Payer Type, Product Line — parallel analytic plans, native since Odoo 16 (before that you had one analytic axis plus tags). The demo invoice INV/2026/00001 carries a 100% distribution across all three on its line. That's the analytic spine: every payer document ties back to the clinical event across three dimensions simultaneously.

**A7. "How does the UDI capture actually work — is GS1 parsing really native?"**
Odoo's barcode app has native GS1 nomenclature support — it can parse Application Identifiers from a scanned GS1 string. We use AI (10) lot/batch, (21) serial, (17) expiry. The parsed values populate the custom UDI fields on `stock.lot`: `x_udi_di` (Device Identifier from product master data), `x_udi_pi` composite plus split batch/serial/expiry fields, and — the detail auditors like — `x_udi_source`, which records whether the identity came from a GS1 scan or manual entry, so data provenance is itself auditable. Non-conforming labels fall back to flagged manual entry (regression case TC-18).

**A8. "What can't Odoo do here? Name the real platform boundaries."**
Four I'll name unprompted: (1) no native dual-authentication e-signature for release actions — our two-step QA release gate is a designed Category 5 control, not a native feature; (2) a sale order natively invoices one partner — payer-split and multi-tier settlement is extension scope; (3) structured EUDAMED-grade UDI reporting depth isn't out of the box — that's the reporting extension, and machine-to-machine EUDAMED submission is Horizon 2; (4) Field Service wasn't on the demo trial tier, so the surgery-event trigger was executed as an inventory move and is labeled SIMULATED in the UAT guide. A partner who can't name the platform's boundaries can't be trusted on its strengths.

**A9. "Odoo.sh vs Odoo Online vs on-premise — and why?"**
Odoo.sh, firmly. Online applies platform upgrades on Odoo's schedule — infrastructure change timing outside the client's control, which conflicts with review-before-promotion change control. Odoo.sh gives a staging branch tested against a copy of production before controlled promotion — that staging mechanism *is* the change-control machinery the validation plan depends on. On-premise adds infrastructure qualification burden the client doesn't need. Version stance: current stable at project start, upgraded on a controlled cadence — never an old release held back indefinitely.

**A10. "Studio fields and automations — do they survive version upgrades?"**
Better than external custom modules, because they live as data (fields, views, rule definitions) that Odoo's upgrade service carries forward — but I won't claim zero-touch. The validation plan explicitly budgets a delta-assessment against the Configuration Specification on every release cycle, and the regression suite re-runs on every candidate. Upgrade risk is managed, not assumed away.

**A11. "How was the demo actually built — Studio clicking or code?"**
Configuration via the platform's external API (XML-RPC) plus Studio for fields and views — no custom Python modules deployed. That matters for the GAMP argument: the native core is configured product (Category 4); even the extension-layer items are Studio fields and automation rules, held to Category 5 rigor because of what they *do*, not because of how they're implemented.

**A12. "What happens if someone deletes a lot record?"**
They can't hard-delete inside the validated boundary — critical models (`stock.lot`, `quality.check`, `account.move`) run an archive-only policy. Archiving hides; it doesn't destroy, and the audit trail survives. And posted accounting entries are protected by Odoo's own posting mechanics on top of that.

**A13. "Is the chatter really a GxP audit trail? An admin could tamper."**
The chatter plus field-level tracking gives timestamped, user-attributed change history that isn't editable through the UI — tracking values are system-written. I'm careful with the claim: I say it satisfies the audit-trail requirement *with the archive-only policy and role design around it*. Admin-privilege governance — who holds superuser, change control on technical settings — is part of the IQ/OQ scope, and in a real audit you'd show admin access is itself controlled and logged. That layered answer is the honest one, and it's the one that survives an auditor.

**A14. "Could the QA lead override the 90-day hold in an emergency?"**
Not by moving stock — the gate refuses. The legitimate path is the disposition route: a logged Extended Hold / early-release decision through the Disposition location with a recorded reason and the two-person release principle. The point of the design is that *override is a documented quality decision, not a warehouse action*.

**A15. "Two lots with the same serial — what stops that?"**
Serial-tracked products enforce uniqueness per product in Odoo; the register in T-09 shows one identity per unit. Cross-product collisions are prevented by the DI + PI structure — identity is the composite, which is exactly how UDI is designed to work.

## B · Regulatory & GxP

**B1. "Defend the mixed GAMP 5 classification. Studio automations as Category 4 — really?"**
GAMP 5 is risk-based, and classification follows what the component does relative to native capability. The core — credential fields, quarantine routing, analytic plans — is configuration of shipped product behavior: Category 4, validated via Configuration Specification and risk-based testing. The extension layer goes *beyond* native behavior (UDI reporting depth, payer splits, cycle enforcement, the dual release gate), so it gets Category 5 rigor even though it's implemented with the same Studio tooling. Implementation technology doesn't set the category; functional novelty and risk do. Blanket Category 4 wouldn't survive an auditor; blanket Category 5 wastes the client's money. Mixed is the defensible position.

**B2. "Which regulation actually requires UDI traceability?"**
EU MDR Article 27 — the UDI system: devices carry a UDI, economic operators store and keep it, and Class III implantables carry the strictest storage obligations through the supply chain. Article 18 adds the implant card obligation for implantable devices. And the registration side is EUDAMED: the UDI/device registration module became mandatory 28 May 2026; legacy devices already on the market must be registered by 27 November 2026 — that statutory deadline is what anchors Horizon 2 Move 1.

**B3. "Why cite 21 CFR Part 11 for a German company?"**
Two reasons: any US market exposure puts them under FDA jurisdiction for those devices, and Part 11 is the lingua franca of computerized-system compliance — auditors and notified bodies treat it alongside EU GMP Annex 11 (EudraLex Vol. 4) as the accepted benchmark. The package applies Annex 11 and Part 11 §11.10/11.50 as the standard the two-step release gate satisfies in *intent* — dual control — while stating plainly that native dual-auth e-signature doesn't exist in Odoo.

**B4. "What's the data-retention position for implantables?"**
MDR/GxP retention for implantables typically runs 10–15 years post-manufacture. The tension I flag is that GDPR minimization pulls the other way on patient-linked fields — so the design principle is two retention rules layered on one record: the device history persists, the patient-identifying attributes may not. That's a named discovery decision with the client's DPO, not something I'd pretend to have solved from outside.

**B5. "Is patient data in a CRM even lawful?"**
It's special-category health data under GDPR Article 9, so it needs its own lawful basis, likely a DPIA before go-live, and clarity on the controller/processor relationship if hospitals enter data. I name that as a distinct legal workstream owned by MDR's legal/DPO function — a solution architect who claims to have settled Article 9 questions in a pre-sales package is someone you shouldn't hire.

**B6. "What is IQ/OQ/PQ in this context, concretely?"**
IQ: the tenant's configuration baseline matches the Configuration Specification — fields, rules, locations exist as specified. OQ: each control fires correctly in isolation — credential block, hold gate, UDI parse — proven by attempting the non-compliant transaction. PQ: the full lifecycle runs correctly under production-representative volume and real user roles. Then a signed Validation Summary Report closes the loop, and every later change references it. The UAT guide in the package is effectively a pre-executed OQ pattern on demonstration data.

**B7. "What happens to open complaints and CAPAs at cutover?"**
They stay owned in the legacy QMS through resolution and migrate only once formally closed — open records are never re-opened fresh mid-cutover in the new system. Closed records migrate as reference data. New activity on an already-migrated device opens in Odoo. Parallel-run default: shorter of 90 days or natural closure of the oldest open record — a discovery-confirmed position. Legacy goes to read-only archive, not decommissioning, because retention outlives the system.

**B8. "And the LIMS — replaced or kept?"**
Position, stated as a position: quality *workflows* consolidate into Odoo Quality; laboratory instrumentation data capture likely stays in the LIMS, integrated rather than replaced — confirmed in discovery. "Integrate, not replace" is also the honest scope answer for hospital IT (HL7/FHIR) — deliberately out of Phase 1.

**B9. "Your audit trail says non-editable. What about direct database access on Odoo.sh?"**
At the application layer the controls hold; at the platform layer, Odoo.sh shell/DB access is restricted to named technical roles and is itself part of the qualified infrastructure story — access governance, logging, and the fact that staging-to-production promotion is the only sanctioned change path. I won't claim DB-level immutability that no ERP has; I claim a controlled, attributable change environment — which is what Annex 11 actually asks for.

**B10. "EUDAMED — what exactly is mandatory today?"**
The first group of modules — including UDI/device registration — became mandatory 28 May 2026 after the Commission's phased-rollout amendment (Regulation 2024/1860 timeline). New devices must be registered before placing on the EU market; devices already on the market have until 27 November 2026. Machine-to-machine submission specs exist and that's the Horizon 2 Autopilot's integration target — sized against the Commission's current M2M spec at build time.

## C · Commercial & delivery

**C1. "What does this cost?"**
The discovery sprint is fixed-fee — three weeks, priced in the SOW [the figure is deliberately a placeholder in the pre-read; a number printed before discovery would be a guess dressed as a promise]. Implementation is committed *at the end of discovery* — a plan, not a guess, same discipline as the fee. What I will say now: total cost of ownership lands at a fraction of the SAP-tier alternative, and the license footprint is per-user Odoo Enterprise, which is public pricing.

**C2. "Timeline to go-live?"**
Phased: 3-week discovery, two configuration sprints (Sales & Quality first — the credential gate and quarantine automation are live in a test instance inside Sprint 1), then validation & data migration with a parallel run, then module-by-module go-live with hypercare. No big bang. Durations beyond discovery are indicative until discovery commits them — that's on the roadmap page in exactly those words.

**C3. "What do you need from the client's people?"**
Two process owners per department, roughly one day a week during their module's sprint — for decisions and own-data testing, not data entry. Bounded, named, and in the change-management doc.

**C4. "What if we just want it all live at once?"**
I'd push back with the regulatory argument: a validated state is demonstrated module by module; a big bang forces you to validate everything simultaneously under go-live pressure, which is where audit findings are born. The phased plan keeps regulatory adherence continuous at every boundary. If speed is the concern, the answer is that value lands in weeks — inside Sprint 1 — not that risk lands all at once.

**C5. "Why should much. put you in front of clients on Odoo when your delivery record is SAP?"**
Because of what's on the table: I didn't submit slides about Odoo, I submitted a running Odoo system with sixteen executed test scenarios and four controls that refuse non-compliant transactions live. My years of enterprise CX/ERP architecture — requirements discipline, integration patterns, regulated-industry governance — transfer whole. The product knowledge gap I closed the way I'd close it on any engagement: by building. Ask me anything about what I built.

## D · SAP-transition attacks

**D1. "What do you NOT yet know about Odoo? Be honest."**
Fair question, and I keep a live list: I haven't yet run a production Odoo.sh upgrade cycle end-to-end on a customer database; my accounting-localization depth (German GoBD/DATEV specifics) is study-level, not delivery-level; and module internals I haven't needed — HR, e-commerce — I know at overview level. What I do know cold is everything in this package, because I built and tested it. My plan for the gaps is the same discipline: build against them in the first engagements, paired with much.'s existing delivery leads.

**D2. "Isn't Odoo a toy compared to what you're used to?"**
It's a different design philosophy, not a lesser one. SAP separates and specializes; Odoo unifies on one data model — which for a mid-market manufacturer is a *feature*: the digital thread in this package is one query precisely because lot, quality check, movement, and invoice share one database and one ORM. The honest comparison is fit-for-segment, and in this segment Odoo wins on coverage-per-euro by a distance.

**D3. "Which SAP habits did you have to unlearn?"**
The instinct to solve everything with a specification document before touching the system. Odoo's cost of experiment is near zero — the right move is configure, test, show, then specify what worked. You can see that inversion in this package: the live system came before the functional spec, and the spec documents what is proven rather than what is hoped.

**D4. "Where would you still recommend SAP?"**
Global multi-entity manufacturers with deep variant configuration, complex inter-company, and thousands of users — genuinely SAP's home turf. MDR Devices is nowhere near that profile. Recommending the same tool for every client is what vendors do; consultants match the tool to the client.

## E · AI usage

**E1. "How much of this did AI do?"**
The volume, under my direction — and there's a two-page working-method note in front of you with the exact split. I set the strategy, the document architecture, and the acceptance bar; AI tooling produced drafts, configuration work, and research at speed; nothing survived into the deliverable without verification against the running system. The note includes the correction log — six real defects the tooling produced that I caught and fixed, each re-proven live.

**E2. "How do you know the AI didn't hallucinate something you missed?"**
Structurally, not hopefully: every technical claim in the package traces to a named record in the live instance or a cited regulation — that's what the RTM and the UAT evidence exist for. The claims that *couldn't* be verified live are labeled design-ready or discovery-scoped rather than asserted. Verification wasn't a final pass; it was the acceptance criterion throughout.

**E3. "Would you use AI on client work here?"**
Yes, under the same rule I propose for MDR Devices' own AI layer: AI drafts, it never releases — with client data protection as a first-class constraint: provider terms, scope exclusions, no special-category data in any AI context without a named legal basis. The working-method note is effectively my proposal for how much. could formalize exactly that.

**E4. "Doesn't heavy AI use devalue your expertise?"**
The correction log answers that better than I can: catching a credential gate sequenced *after* dispatch is control-logic judgment; knowing that FIFO silently overrode standard costs is platform knowledge; deciding that honest scoping beats feature-maximalism is consulting experience. The machine amplified all three; it possesses none of them.

## F · Demo curveballs (live-system questions)

**F1. "Confirm that blocked order right now with an admin override."**
There's no override path on the rule by design — the block is unconditional for Expired/Suspended. The legitimate route is fixing the credential record: update the physician's validation state through the governed process, then confirm. Want me to show the locum route instead? That's the designed exception path — confirm-with-mandatory-review, on the record.

**F2. "Show me exactly where that automation is configured."**
[Settings → Technical → Automation Rules → 'MDR Credential Gate'.] Trigger model, trigger event, and the rule logic are all inspectable — nothing is hidden in code you can't see. That transparency is itself part of the validation story: the Configuration Specification points at these exact records.

**F3. "What if the hospital scans a barcode you can't match?"**
Designed for: an unscannable or unmatched return creates an Under Investigation record routed to Quality rather than being force-matched or dropped — that's regression case TC-17b. The worst traceability failure isn't a missing scan; it's a *wrong* silent match.

**F4. "Kill your internet — what's your demo fallback?"**
The UAT & Golden Path Guide: every scenario has an annotated screenshot of the decisive screen, captured from this same instance. The pitch degrades from live to documented evidence, not from live to nothing.

**F5. "Why is T-14 'simulated'? Sounds like hand-waving."**
The opposite — it's the declared boundary. Field Service isn't available on this trial tier, so the consumption trigger was executed as a direct inventory move and labeled SIMULATED in capital letters rather than disguised. The production design uses the FSM 'Surgery Complete' event. One deliberately honest cell in the results table buys credibility for the fifteen PASSes around it.

**F6. "This is a demo dataset. Why should any of it survive contact with our real data?"**
It shouldn't be assumed to — that's why deliverable D2 of the SOW is rebuilding this exact configuration on MDR Devices' own data during discovery and re-executing the same sixteen scenarios. The demo proves the mechanisms exist and fire; discovery proves they fire on your data. And the migration pre-flight audit (five reliability tests with red-flag thresholds) exists precisely because real data is where implementations die.

---
*Drill order: F first (live pressure), then A, then B. C/D/E are lower-frequency but higher-stakes — one clean rehearsal each.*
