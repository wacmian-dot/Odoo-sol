# Live Demo Runbook — The Presentation Path
*This is the SHOW runbook (the build runbook is separate). Golden rule: the demo is the three refusals; everything else is connective tissue.*

## Pre-flight (the evening before — non-negotiable)
1. Log in (https://mdr-devices-test.odoo.com/odoo) and click through EVERY stop below. Trial tenants can expire or reset — verify the instance is alive **the evening before AND the morning of**.
2. Confirm states: S00001 still Draft (do NOT "fix" Feldmann's credential); LOT-2607-B still in WH/Quarantine with hold 01/10/2026; TRAY-B-001 still 50/50 and NOT dispatched; SN-HC-0002 still at Klinikum consignment.
3. Close all other browser tabs; sign out of personal accounts; browser zoom ~110%; notifications off.
4. Have the UAT & Golden Path Guide PDF open as instant fallback (every decisive screen is captured in it — if the network dies, the pitch degrades to documented evidence, not to nothing).
5. NEVER type credentials on the projector — log in before screen-sharing.

## The path (12–15 min full; 6-min compressed = stops 2, 4, 6, 8)

**Stop 1 — Identity (30s).** Dashboard. "Every screen you'll see says MDR Devices Medizintechnik GmbH — this is a running system, not a mockup."

**Stop 2 — REFUSAL #1: the credential gate (2 min).** Contacts → Dr. M. Feldmann → show MDR Credential Governance section: status Expired, lapsed 30/04/2026. Open S00001 → Confirm → the block: *"Blocked — HCP certification expired or invalid for Dr. M. Feldmann…"* Order stays Draft.
Then the contrast pair, fast: S00002 (Dr. Weber, Validated, DE-ORT-5512, exp 31/12/2027) confirmed clean — no false positives. S00004 (Dr. Okafor, locum, Pending Verification) confirmed WITH mandatory review activity — "we don't block legitimate surgery for paperwork latency; we put it on the record."
*Line: "One person's memory is no longer a compliance control."*

**Stop 3 — Quarantine by construction (1.5 min).** Inventory → receipt WH/IN/00002 (OrthoAlloy, 10 units) → destination WH/Quarantine, lot LOT-2607-B created. "Inbound cannot land in available stock — that's the receipt route's default destination, configuration not SOP." Show the passed quality check (visual/storage/CoA).

**Stop 4 — REFUSAL #2: the 90-day hold (2 min).** Lot LOT-2607-B → hold release date 01/10/2026 (auto-stamped receipt+90d). Create internal transfer Quarantine → Stock, attempt validate → refused: *"quality hold active for lot LOT-2607-B until 2026-10-01."* **Discard/cancel the draft transfer afterwards — leave no litter.**
*Line: "QC passed — and it still refuses. Both conditions: check passed AND hold elapsed. A control that has never refused anything is just a setting."*

**Stop 5 — Birth of an implant (1.5 min).** WH/MO/00004: consumed LOT-2607-A → produced SN-HC-0003. Open the serial → "MDR Compliance — UDI & Quality" section: DI 04012345678901, composite (10)LOT-2607-A(21)SN-HC-0003(17)280702, UDI source, sterility expiry. "The serial is born already carrying its regulatory identity."

**Stop 6 — Consignment truth (1.5 min).** Inventory by location → SN-HC-0002 at WH/Consignment/Klinikum München, €1,200 on-book. "Physically at the hospital, financially on MDR's balance sheet — the location type makes the ledger tell the truth."

**Stop 7 — Money follows the event (1 min).** INV/2026/00001 — posted, €4,850, line carries 100% across Cost Center / Payer Type / Product Line. "The surgery event triggered this — and every payer document reconciles back to the clinical event on three axes."

**Stop 8 — REFUSAL #3: the instrument loop (1.5 min).** TRAY-A-001 cycle 1/50 (normal loop) vs TRAY-B-001 at 50/50 → attempt dispatch → refused: *"Reuse limit reached… route to retirement."* **Cancel the draft transfer.**
*Line: "Nobody counts cycles on a whiteboard anymore. The tray counts itself and retires itself."*

**Stop 9 — The one-query close (1.5 min).** Traceability report from SN-HC-0003: receipt → quarantine → release → manufacture → consignment → return, one screen. *"EU MDR Article 27 evidence in one screen. That is the Compliant Digital Thread."*

## Recovery moves
| Symptom | Move |
|---|---|
| Instance down / expired | Switch to UAT Guide PDF instantly; say it calmly: "screenshots from the same instance — I'll happily rerun any of these live after the session." No apology spiral. |
| A record isn't in expected state | Skip that stop, use its UAT screenshot, keep momentum. Fix nothing live. |
| Refusal message doesn't appear (rule mis-fired) | Do NOT retry three times in front of them. One retry max, then PDF. Investigate after. |
| Asked to do something destructive ("delete that lot") | Turn it into the archive-only teaching moment — attempt is fine: show there's no hard delete on the validated models. |
| Asked to free-drive ("show me X module") | Fine within installed apps; if it's Field Service or something off-tier: "not on this trial tier — and that boundary is printed in the package rather than papered over." |

## Don'ts
- Don't confirm S00001 ever. Don't release LOT-2607-B. Don't dispatch TRAY-B-001. The blocked states ARE the assets.
- Don't demo Studio/settings screens unprompted (invite F2-type questions on YOUR terms, answer from the Deep-Dive when asked).
- Don't say "hopefully" or "should work" on stage. Every stop on this path has already passed 16 executed scenarios.
